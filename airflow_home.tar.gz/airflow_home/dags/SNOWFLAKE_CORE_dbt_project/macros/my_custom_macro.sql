{% macro my_custom_macro() %}
    select current_date() as today
{% endmacro %}
